//
//  DDBannerModel.m
//  duck
//
//  Created by lll on 2022/1/14.
//

#import "DDBannerModel.h"

@implementation DDBannerModel

@end
