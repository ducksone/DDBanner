//
//  ViewController.m
//  blendBanner
//
//  Created by lll on 2022/1/14.
//

#import "ViewController.h"
#import "DDBlendBannerView.h"
#import "DDBannerModel.h"
#import "BelendViewController.h"

@interface ViewController ()

@property (nonatomic, strong) DDBlendBannerView *blendBanner;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"混合滚动banner";
    
//    [self.view addSubview:self.blendBanner];
//
//    [self addSource];
}

- (void)addSource
{
    NSMutableArray<DDBannerModel *> *testArr = [[NSMutableArray alloc] init];
    
    DDBannerModel *model0 = [[DDBannerModel alloc] init];
    model0.type = DDBannerTypeNetImage;
    model0.filePath = @"https://pics3.baidu.com/feed/f636afc379310a557fc00a222f93f6a080261064.png?token=486a2ae9dd6493b990449343cbd775f7";
    
    DDBannerModel *model1 = [[DDBannerModel alloc] init];
    model1.type = DDBannerTypeNetVideo;
    model1.filePath = @"http://www.w3school.com.cn/example/html5/mov_bbb.mp4";
    
    DDBannerModel *model2 = [[DDBannerModel alloc] init];
    model2.type = DDBannerTypeNetImage;
    model2.filePath = @"https://pics5.baidu.com/feed/7acb0a46f21fbe09cf22a78cf0b6b93a8644ad0e.jpeg?token=be06d8aed8accb65583441b9b828eac6";
    
    DDBannerModel *model3 = [[DDBannerModel alloc] init];
    model3.type = DDBannerTypeLocalVideo;
    NSString *filePath3 = [[NSBundle mainBundle] pathForResource:@"trailer" ofType:@"mp4"];
    model3.filePath = filePath3;
    
    DDBannerModel *model4 = [[DDBannerModel alloc] init];
    model4.type = DDBannerTypeLocalImage;
    model4.filePath = @"test_1";
    
    [testArr addObject:model0];
    [testArr addObject:model1];
    [testArr addObject:model2];
    [testArr addObject:model3];
    [testArr addObject:model4];
    
    self.blendBanner.showArray = testArr;
}

- (DDBlendBannerView *)blendBanner
{
    if (!_blendBanner) {
        CGFloat ylocation = [UIApplication sharedApplication].statusBarFrame.size.height + 44;
        
        _blendBanner = [[DDBlendBannerView alloc] initWithFrame:CGRectMake(0, ylocation, [[UIScreen mainScreen] bounds].size.width, 300)];
    }
    return _blendBanner;
}


- (IBAction)testButtonAction:(id)sender {
    BelendViewController *vc = [[BelendViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}
@end
