//
//  SceneDelegate.h
//  blendBanner
//
//  Created by lll on 2022/1/14.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

